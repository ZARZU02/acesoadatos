package es.florida.ad;

import java.io.File;
import java.io.IOException;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.Scanner;

/**
 * Ev1 es una aplicación de consola que permite gestionar archivos dentro de un directorio.
 * Incluye funcionalidades para listar archivos, buscar texto dentro de archivos y subdirectorios,
 * y configurar opciones para la búsqueda sensible a mayúsculas/minúsculas y acentos.
 */
public class Ev1 {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita la ruta del directorio al usuario
        System.out.println("Introduce la ruta del directorio:");
        String directoryPath = scanner.nextLine();

        // Verifica si la ruta introducida es válida y es un directorio
        File directory = new File(directoryPath);
        if (!directory.isDirectory()) {
            System.out.println("Ruta no válida. Por favor, ingresa un directorio válido.");
            return;
        }

        // Llama al método para listar archivos y subdirectorios
        listFiles(directory, "");

        // Solicita el texto que se desea buscar dentro de los archivos
        System.out.println("Introduce el texto a buscar:");
        String searchText = scanner.nextLine();

        // Configura si la búsqueda será sensible a mayúsculas y minúsculas
        System.out.println("¿Deseas que la búsqueda respete mayúsculas/minúsculas? (s/n):");
        boolean caseSensitive = scanner.nextLine().equalsIgnoreCase("s");

        // Configura si la búsqueda ignorará los acentos
        System.out.println("¿Deseas que la búsqueda ignore acentos? (s/n):");
        boolean ignoreAccents = scanner.nextLine().equalsIgnoreCase("s");

        // Realiza la búsqueda del texto en los archivos del directorio
        searchInDirectory(directory, searchText, caseSensitive, ignoreAccents);
    }

    /**
     * Lista los archivos y subdirectorios de manera recursiva, mostrando información detallada de cada archivo.
     * @param dir Directorio a listar
     * @param indent Espaciado para la presentación de subdirectorios
     */
    public static void listFiles(File dir, String indent) {
        File[] files = dir.listFiles();
        if (files != null) {
            // Recorre todos los archivos y subdirectorios
            for (File file : files) {
                if (file.isFile()) {
                    // Muestra información de archivos
                    showFileInfo(file, indent);
                } else if (file.isDirectory()) {
                    // Muestra subdirectorios y hace una llamada recursiva
                    System.out.println(indent + "Subdirectorio: " + file.getName());
                    listFiles(file, indent + "    ");  // Recursión para explorar subdirectorios
                }
            }
        } else {
            System.out.println(indent + "El directorio está vacío.");
        }
    }

    /**
     * Muestra la información detallada de un archivo, incluyendo nombre, tamaño en KB y última modificación.
     * @param file Archivo del cual mostrar la información
     * @param indent Espaciado para la presentación de archivos en subdirectorios
     */
    public static void showFileInfo(File file, String indent) {
        // Formateo de la fecha de la última modificación del archivo
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        // Formato de la información a mostrar: nombre, tamaño y última modificación
        String fileInfo = String.format("%s%s (%d KB - %s)", indent, file.getName(), file.length() / 1024, sdf.format(file.lastModified()));
        System.out.println(fileInfo);
    }

    /**
     * Realiza una búsqueda de texto en los archivos dentro de un directorio y sus subdirectorios de manera recursiva.
     * @param dir Directorio donde realizar la búsqueda
     * @param searchText Texto a buscar
     * @param caseSensitive Si la búsqueda debe ser sensible a mayúsculas/minúsculas
     * @param ignoreAccents Si la búsqueda debe ignorar los acentos
     */
    public static void searchInDirectory(File dir, String searchText, boolean caseSensitive, boolean ignoreAccents) {
        File[] files = dir.listFiles();
        if (files != null) {
            System.out.println("\nResultados de búsqueda:");
            // Recorre los archivos y subdirectorios
            for (File file : files) {
                if (file.isFile()) {
                    // Busca el texto en el archivo
                    searchInFile(file, searchText, caseSensitive, ignoreAccents);
                } else if (file.isDirectory()) {
                    // Recursión para buscar en subdirectorios
                    searchInDirectory(file, searchText, caseSensitive, ignoreAccents);
                }
            }
        }
    }

    /**
     * Busca coincidencias del texto en un archivo de texto plano.
     * @param file Archivo en el que se realizará la búsqueda
     * @param searchText Texto a buscar
     * @param caseSensitive Si la búsqueda debe ser sensible a mayúsculas/minúsculas
     * @param ignoreAccents Si la búsqueda debe ignorar los acentos
     */
    public static void searchInFile(File file, String searchText, boolean caseSensitive, boolean ignoreAccents) {
        int count = 0;
        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                // Si se deben ignorar los acentos, eliminarlos de la línea y del texto de búsqueda
                if (ignoreAccents) {
                    line = removeAccents(line);
                    searchText = removeAccents(searchText);
                }
                // Si no es sensible a mayúsculas/minúsculas, convertir a minúsculas
                if (!caseSensitive) {
                    line = line.toLowerCase();
                    searchText = searchText.toLowerCase();
                }
                // Contar las coincidencias del texto en la línea actual
                if (line.contains(searchText)) {
                    count++;
                }
            }
            // Mostrar los resultados de la búsqueda para cada archivo
            System.out.println(file.getName() + ": " + count + " coincidencias");
        } catch (IOException e) {
            System.out.println("No se pudo leer el archivo: " + file.getName());
        }
    }

    /**
     * Elimina los acentos de una cadena de texto, utilizando Normalizer.
     * @param text Texto original
     * @return Texto sin acentos
     */
    public static String removeAccents(String text) {
        return Normalizer.normalize(text, Normalizer.Form.NFD)
                .replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
    }
}

