package es.florida.ad;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Ev1 {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Introduce la ruta del directorio:");
        String directoryPath = scanner.nextLine();

        File directory = new File(directoryPath);
        if (!directory.isDirectory()) {
            System.out.println("Ruta no válida. Por favor, ingresa un directorio válido.");
            return;
        }

        listFiles(directory);

        System.out.println("Introduce el texto a buscar:");
        String searchText = scanner.nextLine();

        System.out.println("¿Deseas que la búsqueda respete mayúsculas/minúsculas? (s/n):");
        boolean caseSensitive = scanner.nextLine().equalsIgnoreCase("s");

        searchInDirectory(directory, searchText, caseSensitive);
    }

    public static void listFiles(File dir) {
        File[] files = dir.listFiles();
        if (files != null) {
            System.out.println("\nArchivos en el directorio:");
            for (File file : files) {
                if (file.isFile()) {
                    showFileInfo(file);
                } else if (file.isDirectory()) {
                    System.out.println("Subdirectorio: " + file.getName());
                }
            }
        } else {
            System.out.println("El directorio está vacío.");
        }
    }

    public static void showFileInfo(File file) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        String fileInfo = String.format("%s (%d KB - %s)", file.getName(), file.length() / 1024, sdf.format(file.lastModified()));
        System.out.println(fileInfo);
    }

    public static void searchInDirectory(File dir, String searchText, boolean caseSensitive) {
        File[] files = dir.listFiles();
        if (files != null) {
            System.out.println("\nResultados de búsqueda:");
            for (File file : files) {
                if (file.isFile()) {
                    searchInFile(file, searchText, caseSensitive);
                }
            }
        }
    }

    public static void searchInFile(File file, String searchText, boolean caseSensitive) {
        int count = 0;
        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (caseSensitive) {
                    if (line.contains(searchText)) {
                        count++;
                    }
                } else {
                    if (line.toLowerCase().contains(searchText.toLowerCase())) {
                        count++;
                    }
                }
            }
            System.out.println(file.getName() + ": " + count + " coincidencias");
        } catch (IOException e) {
            System.out.println("No se pudo leer el archivo: " + file.getName());
        }
    }
}
